// options.js

document.addEventListener("DOMContentLoaded", async function () {
    const domainList = document.getElementById("domainList");
    const addDomainButton = document.getElementById("addDomainButton");
    const saveButton = document.getElementById("saveButton");

    // Load the current blocked domains from storage
    const storedDomains = await browser.storage.sync.get('blockedDomains');
    let blockedDomains = storedDomains.blockedDomains || [];

    // Function to render the domain list
    function renderDomainList() {
        domainList.innerHTML = '';
        blockedDomains.forEach((domain, index) => {
            const domainItem = document.createElement('div');
            domainItem.className = 'domain-item';

            const input = document.createElement('input');
            input.type = 'text';
            input.value = domain;
            input.addEventListener('input', (event) => {
                blockedDomains[index] = event.target.value;
            });

            const removeButton = document.createElement('button');
            removeButton.textContent = 'Remove';
            removeButton.addEventListener('click', () => {
                blockedDomains.splice(index, 1);
                renderDomainList();
            });

            domainItem.appendChild(input);
            domainItem.appendChild(removeButton);
            domainList.appendChild(domainItem);
        });
    }

    // Add new domain input field
    addDomainButton.addEventListener('click', () => {
        blockedDomains.push('');
        renderDomainList();
    });

    // Save the blocked domains to storage
    saveButton.addEventListener('click', () => {
        browser.storage.sync.set({ blockedDomains: blockedDomains.filter(domain => domain.trim() !== '') });
        alert('Blocked domains saved successfully!');
    });

    // Initial render
    renderDomainList();
});
